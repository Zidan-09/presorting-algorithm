mod metrics;
mod algorithms;
mod utils;

use std::time::Instant;
use std::time::Duration;
use std::thread::sleep;
use sysinfo::{System, Pid, ProcessesToUpdate, ProcessRefreshKind};
use metrics::{Tracker};
use algorithms::*;
use utils::generator::ArrayType;
use algorithms::sorttype::SortType;

use clap::Parser;

#[derive(Parser, Debug)]
#[command(author, version, about = "Benchmark Científico de Algoritmos")]
struct Args {
    #[arg(value_enum)]
    sort_type: SortType,

    #[arg(value_enum)]
    array_type: ArrayType,

    #[arg(short, long, default_value_t = 10000)]
    size: usize
}

fn run_bench<F>(
    algorithm_name: &str, 
    array_type: ArrayType, 
    size: usize, 
    with_presort: bool, 
    mut sort_logic: F
) 
where F: FnMut(&mut [i32], &mut Tracker) {
    let mut sys = System::new_all();
    let pid = Pid::from(std::process::id() as usize);
    let mut tracker = Tracker::new();
    
    let mut data = utils::generator::generate(size, array_type.clone());
    
    let mut warmup = data.clone();
    if with_presort {
        presort::apply(&mut warmup, &mut Tracker::new());
    }
    sort_logic(&mut warmup, &mut Tracker::new());

    sys.refresh_all();
    
    let mut pre_time_ms = 0.0;
    
    let total_start_time = Instant::now();
    
    if with_presort {
        let mut pre_tracker = Tracker::new(); 
        let pre_start = Instant::now();
        
        presort::apply(&mut data, &mut pre_tracker);
        
        pre_time_ms = pre_start.elapsed().as_secs_f64() * 1000.0;
        
        tracker.pre_comparisons = pre_tracker.comparisons;
        tracker.pre_swaps = pre_tracker.swaps;
        tracker.pre_time_ms = pre_time_ms;
    }
    
    sort_logic(&mut data, &mut tracker);
    
    let total_duration = total_start_time.elapsed();
    let total_time_ms = total_duration.as_secs_f64() * 1000.0;
    
    let sort_only_time_ms = total_time_ms - pre_time_ms;
    
    sleep(Duration::from_millis(10));
    sys.refresh_processes_specifics(
        ProcessesToUpdate::Some(&[pid]),
        false,
        ProcessRefreshKind::default().with_cpu().with_memory()
    );

    let mem = sys.process(pid).map(|p| p.memory()).unwrap_or(0);

    println!("--- {} (Com Pré-sort: {}) ---", algorithm_name, with_presort);
    println!("Tempo Total Execução:    {:.4}ms", total_time_ms);
    println!("Comparações (Ordenação): {}", tracker.comparisons);
    println!("Trocas (Ordenação):      {}", tracker.swaps);
    if with_presort {
        println!("Tempo Pré-processamento: {:.4}ms", pre_time_ms);
        println!("Tempo Só Ordenação:      {:.4}ms", sort_only_time_ms);
    }
    if with_presort {
        println!("Comparações (Pré-sort):  {}", tracker.pre_comparisons);
        println!("Trocas (Pré-sort):      {}", tracker.pre_swaps);
    }
    println!("Memória: {} KB\n", mem / 1024);
}

fn main() {
    let args = Args::parse();

    match args.sort_type {
        SortType::Bubble => {
            run_bench("Bubble Sort", args.array_type.clone(), args.size, false, |arr, track| {
                bubble::sort(arr, track);
            });

            run_bench("Bubble Sort", args.array_type.clone(), args.size, true, |arr, track| {
                presort::apply(arr, track);
                bubble::sort(arr, track);
            });
        }
        SortType::Insertion => {
            run_bench("Insertion Sort", args.array_type.clone(), args.size, false, |arr, track| {
                insertion::sort(arr, track);
            });

            run_bench("Insertion Sort", args.array_type.clone(), args.size, true, |arr, track| {
                presort::apply(arr, track);
                insertion::sort(arr, track);
            });
        }
        SortType::Selection => {
            run_bench("Selection Sort", args.array_type.clone(), args.size, false, |arr, track| {
                selection::sort(arr, track);
            });

            run_bench("Selection Sort", args.array_type.clone(), args.size, true, |arr, track| {
                presort::apply(arr, track);
                selection::sort(arr, track);
            });
        }
        SortType::Quick => {
            run_bench("Quick Sort", args.array_type.clone(), args.size, false, |arr, track| {
                quick::sort(arr, track);
            });

            run_bench("Quick Sort", args.array_type.clone(), args.size, true, |arr, track| {
                presort::apply(arr, track);
                quick::sort(arr, track);
            });
        }
        SortType::Merge => {
            run_bench("Merge Sort", args.array_type.clone(), args.size, false, |arr, track| {
                merge::sort(arr, track);
            });

            run_bench("Merge Sort", args.array_type.clone(), args.size, true, |arr, track| {
                presort::apply(arr, track);
                merge::sort(arr, track);
            });
        }
    }
}