use rand::Rng;

#[derive(Debug, Clone, clap::ValueEnum)]
pub enum ArrayType { 
    Random, 
    Inverted, 
    ZigZag, 
    AlmostSorted,
    Turtles 
}

pub fn generate(size: usize, array_type: ArrayType) -> Vec<i32> {
    let mut rng = rand::thread_rng();
    
    match array_type {
        ArrayType::Inverted => (0..size as i32).rev().collect(),
        
        ArrayType::Random => (0..size)
            .map(|_| rng.gen_range(0..1000000))
            .collect(),
            
        ArrayType::ZigZag => (0..size)
            .map(|i| if i % 2 == 0 { i as i32 } else { (size - i) as i32 })
            .collect(),
            
        ArrayType::Turtles => (0..size)
            .map(|i| {
                if i < size / 2 {
                    (i + size) as i32
                } else {
                    (i % 10) as i32
                }
            })
            .collect(),
            
        ArrayType::AlmostSorted => {
            let mut v: Vec<i32> = (0..size as i32).collect();
            for _ in 0..(size / 100) {
                let i = rng.gen_range(0..size);
                let j = rng.gen_range(0..size);
                v.swap(i, j);
            }
            v
        }
    }
}