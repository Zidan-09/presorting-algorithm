pub struct Tracker {
    pub comparisons: u64,
    pub swaps: u64,
    pub pre_comparisons: u64,
    pub pre_swaps: u64,
    pub pre_time_ms: f64,
}

impl Tracker {
    pub fn new() -> Self {
        Self { comparisons: 0, swaps: 0, pre_comparisons: 0, pre_swaps: 0, pre_time_ms: 0.0 }
    }
}