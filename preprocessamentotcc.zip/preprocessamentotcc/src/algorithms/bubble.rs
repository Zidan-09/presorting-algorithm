use crate::metrics::Tracker;

pub fn sort(arr: &mut [i32], tracker: &mut Tracker) {
    let n = arr.len();
    let mut swapped = true;
    while swapped {
        swapped = false;
        for i in 0..n.saturating_sub(1) {
            tracker.comparisons += 1;
            if arr[i] > arr[i + 1] {
                arr.swap(i, i + 1);
                tracker.swaps += 1;
                swapped = true;
            }
        }
    }
}