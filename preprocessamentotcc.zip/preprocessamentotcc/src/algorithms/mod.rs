pub mod bubble;
pub mod insertion;
pub mod selection;
pub mod quick;
pub mod merge;
pub mod presort;
pub mod sorttype;