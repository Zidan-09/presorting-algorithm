use crate::metrics::Tracker;

pub fn sort(arr: &mut [i32], tracker: &mut Tracker) {
    for i in 1..arr.len() {
        let value = arr[i];
        let mut j = i as i32 - 1;

        while j >= 0 {
            tracker.comparisons += 1;
            if arr[j as usize] > value {
                arr[(j + 1) as usize] = arr[j as usize];
                tracker.swaps += 1;
                j -= 1;
            } else {
                break;
            }
        }
        arr[(j + 1) as usize] = value;
    }
}