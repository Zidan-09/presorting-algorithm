
#[derive(Debug, Clone, clap::ValueEnum)]
pub enum SortType {
    Bubble,
    Insertion,
    Selection,
    Quick,
    Merge
}