use crate::metrics::Tracker;

pub fn sort(arr: &mut [i32], tracker: &mut Tracker) {
    let n = arr.len();
    if n < 2 {
        return;
    }

    let mid = n / 2;
    // Criamos cópias para as metades (equivalente ao .slice do TS)
    let mut left = arr[0..mid].to_vec();
    let mut right = arr[mid..n].to_vec();

    sort(&mut left, tracker);
    sort(&mut right, tracker);

    merge(arr, &left, &right, tracker);
}

fn merge(arr: &mut [i32], left: &[i32], right: &[i32], tracker: &mut Tracker) {
    let (mut l, mut r, mut s) = (0, 0, 0);
    let left_size = left.len();
    let right_size = right.len();

    while l < left_size && r < right_size {
        tracker.comparisons += 1;
        if left[l] <= right[r] {
            arr[s] = left[l];
            l += 1;
        } else {
            arr[s] = right[r];
            r += 1;
        }
        tracker.swaps += 1;
        s += 1;
    }

    while l < left_size {
        arr[s] = left[l];
        l += 1;
        s += 1;
        tracker.swaps += 1;
    }

    while r < right_size {
        arr[s] = right[r];
        r += 1;
        s += 1;
        tracker.swaps += 1;
    }
}