use crate::metrics::Tracker;
use rand::Rng;

pub fn sort(arr: &mut [i32], tracker: &mut Tracker) {
    let len = arr.len();
    if len < 2 { return; }
    quick_sort_recursive(arr, 0, (len - 1) as i32, tracker);
}

fn quick_sort_recursive(arr: &mut [i32], low: i32, high: i32, tracker: &mut Tracker) {
    if low >= high { return; }

    let mut rng = rand::thread_rng();
    let pivot_idx = rng.gen_range(low..=high) as usize;
    let pivot = arr[pivot_idx];

    arr.swap(pivot_idx, high as usize);
    tracker.swaps += 1;

    let mut left = low;
    let mut right = high - 1;

    while left <= right {
        while left <= right {
            tracker.comparisons += 1;
            if arr[left as usize] < pivot { left += 1; } else { break; }
        }
        while left <= right {
            tracker.comparisons += 1;
            if arr[right as usize] > pivot { right -= 1; } else { break; }
        }
        if left <= right {
            arr.swap(left as usize, right as usize);
            tracker.swaps += 1;
            left += 1;
            right -= 1;
        }
    }

    arr.swap(left as usize, high as usize);
    tracker.swaps += 1;

    quick_sort_recursive(arr, low, left - 1, tracker);
    quick_sort_recursive(arr, left + 1, high, tracker);
}