use crate::metrics::Tracker;

pub fn apply(arr: &mut [i32], tracker: &mut Tracker) {
    let len = arr.len();
    if len < 2 { return; }
    let last = len - 1;
    let mid = len / 2;

    for i in 0..mid {
        let j = last - i;
        tracker.comparisons += 3;

        if arr[i] > arr[j] {
            arr.swap(i, j);
            tracker.swaps += 1;
        }
        if i + 1 < mid && arr[i] > arr[i + 1] {
            arr.swap(i, i + 1);
            tracker.swaps += 1;
        }
        if j > mid && arr[j] < arr[j - 1] {
            arr.swap(j, j - 1);
            tracker.swaps += 1;
        }
    }
}