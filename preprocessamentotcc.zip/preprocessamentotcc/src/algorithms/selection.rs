use crate::metrics::Tracker;

pub fn sort(arr: &mut [i32], tracker: &mut Tracker) {
    let n = arr.len();
    for i in 0..n {
        let mut minor_idx = i;

        for j in (i + 1)..n {
            tracker.comparisons += 1;
            if arr[j] < arr[minor_idx] {
                minor_idx = j;
            }
        }

        if minor_idx != i {
            arr.swap(i, minor_idx);
            tracker.swaps += 1;
        }
    }
}